#Step1 pip install gTTS
#Step2 import os
#Step3 Enter text that you want to Convert
#Step4 Deciding Lang = 'en;
#Step5 Calling gTTS() Contructor
#Step6 SAving file
#Step7 OPening the file
import os

from gtts import gTTS
myText= " Hi Every One, Hope Yo are learning Some thing new "
language='en'
myObj = gTTS(text=myText,lang=language,slow=True)
myObj.save("message.mp3")#saving the file
os.system("message.mp3")#opening the file
#Step 1 install pyqrcode( pip)
#Step 2 install Pypng
#Step 3 Create a String for which you want QR code
#Step 4 Save it as SVG/PNG
#Major.Minor.Build.Revision
import  pyqrcode
import png
from pyqrcode import QRCode

mylinkedinLink = "https://www.linkedin.com/in/parth-shukla-09205239/"
myEmail = " parth.Shukla3@hotmail.com"
url= pyqrcode.create(mylinkedinLink + myEmail)
url.svg("myqr.svg",scale=8)
url.png('myqr.png', scale=6)
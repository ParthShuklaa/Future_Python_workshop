myPassword = {
   "Facebook": "QWERTY@123",
    "Gmail": "123456789@123",
    "Instagram": "PASSWORD@123",
    "Facebook":"123456"
}

myPassword["Gmail"] = "I am feeling Lucky"
print(len(myPassword))
print(myPassword["Gmail"])
#print(type(myPassword))
#print(myPassword["Facebook"])

#Step1: import smtplib
#Step2: We Will Create a Session, using SMTP connection
import smtplib
session = smtplib.SMTP('smtp.gmail.com',587)
session.starttls()
#Authentication
session.login("Senders Address ","YourPassword")
Message="To day was my First Workshop on mastering Python...!!!!"
session.sendmail("Senders Address","reciever Address",Message)
session.quit()
#Working with List- Helps us in storing muliple vslues in same variable
favMovies = ["Suryavansham","KGF","kGF"]
print(favMovies)
print(favMovies[1])
favMovies[0]="Avengers- End Game"
print(favMovies)
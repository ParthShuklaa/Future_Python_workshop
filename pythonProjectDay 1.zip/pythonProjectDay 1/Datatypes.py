x=str(5)
X=20
# python is case sensitive
y=int(10)
z=float(9)
name="Future_College"#string type
city='Bareilly Smart City'

print(y)
print(z)
print(X)
print(name)
print(type(city))